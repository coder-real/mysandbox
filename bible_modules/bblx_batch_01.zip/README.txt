Modules are in modules/. Install only after testing in your version of e-Sword.
Original OSIS source JSON, including source annotations, is compressed in source_osis/.
Those annotations are NOT converted to interactive e-Sword markup. SQL exports may
contain normalized text that differs from the OSIS source. Verses outside the
standard 66 books, duplicate references, and non-positive references are stored
in each module's UnmappedVerses table, not displayed in e-Sword. See the JSON report.
Licences vary; check the report and upstream sources before redistribution.
