KJVPCE sample only, not the full 140-translation collection.
Source: scrollmapper/bible_databases, revision 59b18c5af5845728c275d5b7178ad0d024172b1f; formats/json/KJVPCE.json.
KJVPCE source licence: public domain.
The source used for this sample is plain-text JSON: formatting present in the separate OSIS source, such as italics, is not included.
The SQLite database passed integrity and verse count checks; it has not been tested in e-Sword.
